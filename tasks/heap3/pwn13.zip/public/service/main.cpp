#include <map>
#include <cstdio>
#include <iostream>
#include <unistd.h>
#include <sys/mman.h>

class parent_class {
  public:
    virtual void greet() {std::cout << "I am parent class" << '\n';}
};


class daughter_class: parent_class {
  public:
    void greet() {std::cout << "I am daughter class" << '\n';}
};

void* ptr;
void* objects[32] = {0};
std::map<int,int> added_objs;

void setup() {
  setvbuf(stdin, NULL, _IONBF, 0);
  setvbuf(stdout, NULL, _IONBF, 0);
}

int get_free_index() {
  for (int i = 0; i < sizeof objects; i++) {
    if (!objects[i]) {
      return i;
    }
  }
  return -1;
}

void menu() {
  std::cout << "1. Create parent object" << '\n';
  std::cout << "2. Create daughter object" << '\n';
  std::cout << "3. Create buffer" << '\n';
  std::cout << "4. Delete object" << '\n';
  std::cout << "5. Print buffer" << '\n';
  std::cout << "6. Make object greet" << '\n';
  std::cout << "7. Create shellcode" << '\n';
  std::cout << "8. Exit" << '\n';
}

int main() {
  int choice, cur_index;
  setup();
  std::cout << "Welcome to your C++ challenge!" << '\n';
  for (;;) {
    menu();
    std::cin >> choice;
    switch (choice) {
      case 1:
        cur_index = get_free_index();
        if (cur_index < 0) {
          break;
        }
        objects[cur_index] = new parent_class;
        added_objs[cur_index] = 1;
        ((parent_class*)(objects[cur_index]))->greet();
        break;
      case 2:
        cur_index = get_free_index();
        if (cur_index < 0) {
          break;
        }
        objects[cur_index] = new daughter_class;
        added_objs[cur_index] = 1;
        ((daughter_class*)objects[cur_index])->greet();
        break;
      case 3:
        cur_index = get_free_index();
        if (cur_index < 0) {
          break;
        }
        objects[cur_index] = new char[8];
        std::cout << "Data: ";
        read(0, (char*)objects[cur_index], 8);
        break;
      case 4:
        std::cout << "Index: ";
        std::cin >> cur_index;
        if (cur_index < 0) {
          break;
        }
        delete (parent_class*)objects[cur_index];
        break;
      case 5:
        std::cout << "Index: ";
        std::cin >> cur_index;
        if (cur_index < 0) {
          break;
        }
        std::cout << (char*)objects[cur_index] << '\n';
        break;
      case 6:
        std::cout << "Index: ";
        std::cin >> cur_index;
        if (cur_index < 0 || !added_objs.count(cur_index)) {
          break;
        }
        ((parent_class*)(objects[cur_index]))->greet();
        break;
      case 7:
        ptr = mmap(0, 0x1000, 7, MAP_PRIVATE|MAP_ANONYMOUS, -1, 0);
        std::cout << "Shellcode: ";
        read(0, (char*)ptr, 50);
        break;
      case 8:
        return 0;
      default:
        break;
    }
  }
}
