#!/usr/bin/env bash

FLAG=`cat /tmp/flag.txt` socat tcp-l:1337,fork,reuseaddr exec:"sudo -E -u nobody /task/binary"
