#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

char* chunks[16];
size_t sizes[16];

void setup() {
    setvbuf(stdin, NULL, _IONBF, 0);
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);
}

size_t get_int()
{
    char input[16];
    read(0, input, 15);
    return atol(input);
}

void allocate()
{
    printf("Input location: ");
    size_t pos = get_int();
    if (pos > 15)
    {
        printf("Noup\n");
        return;
    }
    printf("Input size: ");
    size_t size = get_int();
    if (size > 4096 || size < 2)
    {
        printf("Noup\n");
        return;
    }
    chunks[pos] = malloc(size);
    sizes[pos] = size;
    printf("Input data: ");
    read(0, chunks[pos], size - 1);
}

void delete()
{
    printf("Input location: ");
    size_t pos = get_int();
    if (pos > 15)
    {
        printf("Noup\n");
        return;
    }
    free(chunks[pos]);
}

void read_data()
{
    printf("Input location: ");
    size_t pos = get_int();
    if (pos > 15)
    {
        printf("Noup\n");
        return;
    }
    printf("%s\n", chunks[pos]);
}

void change()
{
    printf("Input location: ");
    size_t pos = get_int();
    if (pos > 15)
    {
        printf("Noup\n");
        return;
    }
    printf("Input data: ");
    read(0, chunks[pos], sizes[pos]);
}

void menu()
{
    printf("Enter number\n");
    printf("1. Allocate\n");
    printf("2. Free\n");
    printf("3. Read\n");
    printf("4. Change\n");
    printf("5. Exit\n");
    printf(">> ");
}

int main()
{
    setup();
    while (1)
    {
        menu();
        size_t choice = get_int();
        switch (choice)
        {
            case 1:
                allocate();
                break;
            case 2:
                delete();
                break;
            case 3:
                read_data();
                break;
            case 4:
                change();
                break;
            case 5:
                return 0;
        }
    }
}